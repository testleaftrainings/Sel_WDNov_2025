package base;

import java.time.Duration;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {
	
	//public RemoteWebDriver driver;
	private static final ThreadLocal<RemoteWebDriver> rDriver = new ThreadLocal<RemoteWebDriver>();
	
	//org.openqa.selenium.WebDriverException : TIMEOUT
	//org.openqa.selenium.StaleElementReferenceException : Driver value is same
	@BeforeMethod
	public void preCondition() {
		//driver = new FirefoxDriver();
		setrDriver(new FirefoxDriver());
		getrDriver().manage().window().maximize();
		getrDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		getrDriver().get("http://leaftaps.com/opentaps/control/main");
		System.out.println("From base : "+getrDriver());
		// 
	}
	
	@AfterMethod
	public void postCondition() {
		getrDriver().quit();
	}

	public void setrDriver(RemoteWebDriver driver) {
		rDriver.set(driver);
	}
	
	public RemoteWebDriver getrDriver() {
		return rDriver.get();
	}

}
