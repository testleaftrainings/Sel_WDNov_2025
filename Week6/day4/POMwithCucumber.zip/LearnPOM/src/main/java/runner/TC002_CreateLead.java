package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethod {

	@Test
	public void runCreateLeatTest() {
		System.out.println("From runner TC002 : "+getrDriver());
		// 
		LoginPage user = new LoginPage();
		
		// Singleton design pattern --> constructor chaining
		user.enterUsername("demosalesmanager").enterPassword("crmsfa").clickLoginButton()
		       .user_clicks_the_crmsfa_link()
				  .user_clicks_the_leads_link()
				     .user_clicks_the_create_lead_link()
				     .user_enters_the_company_name_as_testleaf("Qualitest")
				     .user_enters_the_first_name_as_bhuvanesh("Bhuvanesh")
				     .user_enters_the_last_name_as_m("M")
				     .user_enters_the_phone_number("88257")
				     .user_clicks_the_create_lead_submit_button()
				     .user_verify_the_lead_id_using_the_company_name();

	}
}
