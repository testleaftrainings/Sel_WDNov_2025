package runner;

import org.testng.annotations.Test;
import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethod {

	@Test
	public void runLoginTest() {
		// Builder pattern
		System.out.println("From runner TC001 : "+getrDriver());
		// 
		LoginPage lp = new LoginPage();
		lp.enterUsername("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton();
		
	}
	
}
