package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{

	@When("user enters the username as {string}")
	public LoginPage enterUsername(String uname) {
		System.out.println("From Pages : "+getrDriver());
		//java.lang.NullPointerException:
	      getrDriver().findElement(By.id("username")).sendKeys(uname);
	      return this;
	}
	
	@When("user enters the password as {string}")
	public LoginPage enterPassword(String password) {
	      getrDriver().findElement(By.name("PASSWORD")).sendKeys(password);
	      return this;
	}
	
	@When("user clicks the submit button")
	public WelcomePage clickLoginButton() {
          getrDriver().findElement(By.className("decorativeSubmit")).click();
          return new WelcomePage();
	}
}
