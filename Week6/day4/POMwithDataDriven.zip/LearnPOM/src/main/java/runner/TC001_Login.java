package runner;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethod {

	@BeforeClass
	  public void selectDataPath() {
		  filePath= "LoginTest";
	  }
	@Test(dataProvider = "fetchData")
	public void runLoginTest(String uname,String pword) {
		// Builder pattern
		System.out.println("From runner TC001 : "+getrDriver());
		// 
		LoginPage lp = new LoginPage();
		lp.enterUsername(uname)
		.enterPassword(pword)
		.clickLoginButton();
		
	}
	
}
