package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	public LoginPage enterUserName(String uname) {
		clearAndType(locateElement("username"), uname);	
		reportStep("Username entered successfully", "pass");
		return this;
	}
	
	public LoginPage enterPassword(String pword) {
		clearAndType(locateElement("password"), pword);	
		reportStep("password entered successfully", "pass");
		return this;
	}
	
	public LoginPage clickLogInButton() {
		click(locateElement(Locators.XPATH, "//input[@id='Login']"));
		reportStep("Login button clicked successfully", "pass");
		return this;
	}

}
