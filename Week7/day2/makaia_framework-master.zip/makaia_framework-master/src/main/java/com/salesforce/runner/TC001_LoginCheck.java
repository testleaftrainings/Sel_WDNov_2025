package com.salesforce.runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC001_LoginCheck extends ProjectSpecificMethods {

	@BeforeTest
	public void setValues() {
		excelFileName = "Login";
		testcaseName = "Login Check";
		testDescription = "Test to verify the application accepts the valid credentials";
		authors = "Bhuvanesh";
		category = "Smoke";
	}

	@Test(dataProvider = "fetchData")
	public void runLoginTest(String username, String password) {
		LoginPage user = new LoginPage();
		user.enterUserName(username).enterPassword(password).clickLogInButton();
	}
	}
